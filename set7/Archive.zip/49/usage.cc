#include "main.ih"


int usage()
{
    cout << "Usage: <program name> <n_primes>";
    return 1;
}