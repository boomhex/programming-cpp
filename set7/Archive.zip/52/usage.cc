#include "main.ih"

int usage()
{
    cerr << "Usage: <program name> <output filepath> <word>";
    return 1;
}