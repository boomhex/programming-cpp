#include "task.ih"

void Task::setFile(string const &file)
{
    d_file = &file;
}