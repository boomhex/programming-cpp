#include "main.ih"

void inFunc(ostream &out, string const &text)
{
    Handler handler;
    handler.shift(out, text);
}
