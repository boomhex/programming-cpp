#ifndef HANDLE_EXCEPTION_H
#define HANDLE_EXCEPTION_H

int handleException ();

#endif