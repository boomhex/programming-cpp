#ifndef DEMO_H
#define DEMO_H

struct Demo
{
    Demo() = default;
    Demo(int value);
    ~Demo();
};

#endif