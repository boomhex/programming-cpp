#include "demo.ih"

Demo::~Demo()
{
    cerr << "destructor is called\n";
}