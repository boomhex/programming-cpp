#include "main.ih"


void throwObj()
{
    Obj obj{1};
    throw obj;
}
