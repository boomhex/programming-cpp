#include "main.ih"


void whichCopy(Obj const &obj)
{
    std::cout << "Copy no. " << obj <<'\n';
}
