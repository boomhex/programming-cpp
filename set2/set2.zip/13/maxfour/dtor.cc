#include "maxfour.ih"

MaxFour::~MaxFour()
{
    --d_nobjects;
}