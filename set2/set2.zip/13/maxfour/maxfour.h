#ifndef MAXFOUR_H_INCLUDED
#define MAXFOUR_H_INCLUDED

#include <cstddef>

class MaxFour
{
    static size_t d_nobjects;
    public:
        MaxFour();
        ~MaxFour();
};

#endif