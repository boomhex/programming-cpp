#include "fork.ih"

void Fork::parentProcess()
{
    
}