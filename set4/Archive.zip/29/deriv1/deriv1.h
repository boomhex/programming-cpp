#ifndef _INCLUDED_DERIV1_
#define _INCLUDED_DERIV1_

#include "../basic/basic.h"

class Deriv1: virtual public Basic
{
    public:
        Deriv1();
};

#endif