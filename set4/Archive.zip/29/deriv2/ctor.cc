#include "deriv2.ih"

Deriv2::Deriv2()
:
    Basic(3)              // always Calls Basic(int number)
{
    cout << "Deriv2()\n";
}