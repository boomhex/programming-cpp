#include "multi/multi.h"

int main()
{
   Multi multi;
}