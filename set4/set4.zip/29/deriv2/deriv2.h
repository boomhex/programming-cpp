#ifndef _INCLUDED_DERIV2_
#define _INCLUDED_DERIV2_

#include "../basic/basic.h"

class Deriv2: virtual public Basic
{
    public:
        Deriv2();
};

#endif