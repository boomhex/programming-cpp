#ifndef _INCLUDED_BASIC_
#define _INCLUDED_BASIC_

class Basic
{
    public:
        Basic();
        Basic(int number);
};

#endif