#include "basic.ih"

Basic::Basic(int number)
{
    cout << "Basic(int" << number << ")\n";
}