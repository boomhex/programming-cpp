#include "basic.ih"

Basic::Basic()
{
    cout << "Basic()\n";
}