#include "deriv1.ih"

Deriv1::Deriv1()
:
    Basic(3)              // always Calls Basic(int number)
{
    cout << "Deriv1()\n";
}