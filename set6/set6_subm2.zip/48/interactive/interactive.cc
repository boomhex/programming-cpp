#include "interactive.ih"

Interactive::Interactive(char *filename)
:
    d_filename{ filename }
{}