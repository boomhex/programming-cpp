#include "strings.ih"


void Strings::add(std::string const &str)
{
    d_strings.push_back(str);
}
