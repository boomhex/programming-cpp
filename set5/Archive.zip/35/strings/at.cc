#include "strings.ih"


std::string &Strings::at(size_t index)
{
    return d_strings.at(index);
}
