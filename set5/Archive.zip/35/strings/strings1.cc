#include "strings.ih"


Strings::Strings()
:
    d_strings(1)
{}
