#include "strings.ih"


Strings::Strings()
:
    d_vsp()
{}
